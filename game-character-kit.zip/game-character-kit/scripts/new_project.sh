#!/bin/bash
# Scaffold a new game from the character-kit engine.
#   new_project.sh <target-dir> <slug>      e.g. new_project.sh "~/Desktop/CLAUDE - MM WORK FOLDER/viking-src" viking-saga
# Produces a buildable copy (assets + tools + harness). node_modules is symlinked to the skill's copy (no npm install).
set -e
[ -z "$2" ] && { echo "usage: new_project.sh <target-dir> <slug>"; exit 1; }
SK="$(cd "$(dirname "$0")/.." && pwd)"; T="$1"; SLUG="$2"
[ -e "$T" ] && { echo "target exists: $T"; exit 1; }
mkdir -p "$T"
rsync -a --exclude tools/node_modules --exclude build --exclude out "$SK/engine/" "$T/"
ln -s "$SK/engine/tools/node_modules" "$T/tools/node_modules"
echo "$SLUG" > "$T/NAME"
echo "scaffolded $T  (NAME=$SLUG) — next: cd it && ./rebuild.sh && QUIET=1 node tools/shot.js tools/sc_test.js out/t '?test'"
